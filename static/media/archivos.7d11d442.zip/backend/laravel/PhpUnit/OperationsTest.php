<?php
//./tests/OperationsTest.php
use PHPUnit\Framework\TestCase;

class OperationsTest extends TestCase
{
    private $op; //creamos la instancia para los test

    public function setUp():void{ 
        //setUp():void es una function de phpunit que nos va a servir para inicializar nuestros objetos
        $this->op = new Operations(); //aqui inicializamos nuestro objeto
    }
    //a partir de haora ya podemos testear
    public function testSumWithValues(){
        $this->assertEquals(7, $this->op->sum(2,5));
    }
    public function testDivisionWithValues(){
        $this->assertEquals(1, $this->op->division(5,5));
    }

    public function testNulll(){  
        $this->expectException(InvalidArgumentException::class);
        $this->op->sum(null, null);
        //utilizamos expectException para cuando esperamos excepcciones y dentro el tipo de excepción
    }
}

