<?php

/** @var \Laravel\Lumen\Routing\Router $router */


use App\Models\Badge;
use Illuminate\Http\Request;

$router->get('/', function () use ($router) {
    return $router->app->version();
});


//CRUD ;

//CREATE
$router->post('/badge/new_badge', function (Request $request) use ($router) {
    $new_badge = new Badge();
    $new_badge->product = $request->input('product');
    $new_badge->color = $request->input('color');
    if($new_badge->save()){
        return response()->json($new_badge);
    }else{
        return response()->json("error");
    }
});

//READ
$router->get('/badge', function () use ($router) {
    return response()->json(Badge::all());
});

//UPDATE
$router->post('/badge/update', function () use ($router) {
    $findObject = Badge::where('product','=',$request->input('product'))->first();
    if($findObject!=null){
        $findObject->color=$request->input('color');
        $findObject->save();
    //modificar el color.
        return response()->json( $findObject );
    }else{
        return response()->json( 'product not found' );
    }
});

//DELETE
$router->post('/badge/delete', function () use ($router) {
    $findObject = Badge::where('product','=',$request->input('product'))->first();
    if($findObject!=null){
        $findObject->delete();
    //modificar el color.
        return response()->json('product deleted');
    }else{
        return response()->json( 'product not found' );
    }
});
